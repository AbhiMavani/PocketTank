import 'package:flutter/material.dart';
import 'package:gradient_widgets/gradient_widgets.dart';
import 'package:tankgame/components/game_status.dart';
import 'gameMode.dart';
import 'package:tankgame/game_controller.dart';
import 'package:tankgame/components/Tank.dart';

class Player_Details extends StatefulWidget {
  final GameController gameController;
  final Function updateState;
  final _formKey = GlobalKey<FormState>();
  TextEditingController textController = TextEditingController();
  TankColor tankColor;
  List<TankColor> colorForTank;
  int temp;
  String playerName;
  String color;
  Player_Details({Key key, this.gameController, this.updateState}) {
    temp = 1;
    colorForTank = TankColor.getColors();
    // gamemode.playerDetails.clear();
    for (TankColor tankcolor in colorForTank) {
      tankcolor.selectedColor = true;
    }
  }

  @override
  _Player_DetailsState createState() => _Player_DetailsState();
}

class _Player_DetailsState extends State<Player_Details> {
  void setTankColor(String colorName) {
    widget.color = colorName;
  }

  void setName(String name) {
    widget.playerName = name;
  }

  void storeData() {
    if (widget.gameController.noOfPlayer == widget.temp) {
      widget.gameController.gameStatus = Status.playing;
      widget.updateState();
    }

    for (TankColor tankColor in widget.colorForTank) {
      if (tankColor.colorName == widget.color)
        widget.colorForTank.remove(tankColor);
    }

    Tank tank = Tank(
        gameController: widget.gameController,
        playerName: widget.playerName,
        color: widget.color);
    widget.gameController.tanks.add(tank);
    widget.color = null;
  }

  List<Widget> getButton() {
    List<Widget> widgets = [];

    for (TankColor tankcolor in widget.colorForTank) {
      if (tankcolor.selectedColor == true) {
        widgets.add(
          ButtonTheme(
            minWidth: widget.gameController.tileSize * 1.367187,
            child: RaisedButton(
              padding: EdgeInsets.all(widget.gameController.tileSize * 0.17089),
              autofocus: true,
              focusElevation: widget.gameController.tileSize * 0.06835,
              onPressed: () {
                setTankColor(tankcolor.colorName);
              },
              color: tankcolor.color,
              splashColor: Colors.blue[100],
              elevation: widget.gameController.tileSize * 0.034179,
              highlightElevation: widget.gameController.tileSize * 0.06835,
              animationDuration: Duration(milliseconds: 1000),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.elliptical(
                    widget.gameController.tileSize * 0.410156,
                    widget.gameController.tileSize * 0.341796)),
              ),
            ),
          ),
        );
      }
    }

    return widgets;
  }

  Widget userDetailsUi(int number) {
    Widget widgets;
    widget.textController.clear();
    widgets = GradientCard(
      gradient: Gradients.tameer,
      shadowColor: Gradients.tameer.colors.last
          .withOpacity(widget.gameController.tileSize * 0.008544),
      elevation: widget.gameController.tileSize * 0.273437,
      child: Container(
        margin: new EdgeInsets.fromLTRB(
            widget.gameController.tileSize * 6.015624,
            widget.gameController.tileSize * 1.025390,
            widget.gameController.tileSize * 5.468749,
            widget.gameController.tileSize * 2.050781),
        constraints: BoxConstraints.expand(),
        child: SingleChildScrollView(
          child: Form(
            key: widget._formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  "Player $number",
                  style: TextStyle(
                    fontSize: widget.gameController.tileSize * 1.025390,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(
                  height: widget.gameController.tileSize * 0.341796,
                ),
                TextFormField(
                  autofocus: true,
                  autocorrect: true,
                  cursorColor: Colors.black,
                  cursorWidth: widget.gameController.tileSize * 0.17089,
                  decoration: InputDecoration(
                    fillColor: Colors.white,
                    focusColor: Colors.black,
                    hintText: "Enter Your Name",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(
                          widget.gameController.tileSize * 0.17089),
                      borderSide: BorderSide(
                        color: Colors.amber,
                        style: BorderStyle.solid,
                      ),
                    ),
                  ),
                  controller: widget.textController,
                  maxLines: 1,
                  maxLength: 15,
                  toolbarOptions: ToolbarOptions(
                    cut: true,
                    copy: true,
                    selectAll: true,
                    paste: true,
                  ),
                  validator: (String value) {
                    if (value.isEmpty)
                      return "name is required";
                    else {
                      setName(value);
                      return null;
                    }
                  },
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: widget.gameController.tileSize * 1.02539,
                  ),
                ),
                SizedBox(
                  height: widget.gameController.tileSize * 1.02539,
                ),
                Container(
                  height: widget.gameController.tileSize * 0.683593,
                  child: Row(children: getButton()),
                ),
                SizedBox(
                  height: widget.gameController.tileSize * 1.02539,
                ),
                Row(
                  children: <Widget>[
                    Text(
                      "NextPlayer",
                      style: TextStyle(
                        fontSize: widget.gameController.tileSize * 1.02539,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(
                      width: widget.gameController.tileSize * 3.45976,
                    ),

                    ///110
                    RaisedButton.icon(
                      onPressed: () {
//                      print(widget
//                          .gameController.player_details.selectedTankColor);
//                      print(widget.gameController.player_details.playerName);
//
//                      print(widget.gameController.player_details.noOfPlayer);
                        if (widget._formKey.currentState.validate()) {
                          print(widget.color);
                          if (widget.color == null) {
                            Scaffold.of(context).showSnackBar(
                                SnackBar(content: Text('Press Tank Color')));
                          } else {
                            storeData();
                            setState(() {
                              widget.temp++;
                              userDetailsUi(widget.temp);
                            });
                          }
                        }
                      },
                      icon: Icon(Icons.arrow_forward),
                      label: Text(
                        "Next",
                        style: TextStyle(
                          fontSize: widget.gameController.tileSize * 1.025388,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      color: Colors.blueGrey,
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: userDetailsUi(widget.temp),
      ),
    );
  }
}
